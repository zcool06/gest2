<?php
################################################################################
# @Name : cron_daily.php
# @Description : execute tasks in time interval
# @Call : ./index.php
# @Parameters : 
# @Author : Flox
# @Create : 09/05/2019
# @Update : 16/10/2020
# @Version : 3.2.5
################################################################################

//update last execution time
$new_date=date_create($rparameters['cron_daily']);
date_add($new_date, date_interval_create_from_date_string('1 days'));
$new_date=date_format($new_date, 'Y-m-d');
$qry=$db->prepare("UPDATE `tparameters` SET `cron_daily`=:cron_daily");
$qry->execute(array('cron_daily' => $new_date));

//autoclose ticket parameter
require('./core/auto_close.php');

//user validation parameter
require('./core/user_validation.php');

?>