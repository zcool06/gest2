//################################################################################
// @Name : js/ticket.js
// @Description : script to ticket page
// @call : ticket.php
// @parameters : 
// @Author : Flox
// @Create : 21/09/2020
// @Update : 28/09/2020
// @Version : 3.2.5
//################################################################################

//CTRL+S to save ticket 
$(document).keydown(function(e) {
    var key = undefined;
    var possible = [ e.key, e.keyIdentifier, e.keyCode, e.which ];
    while (key === undefined && possible.length > 0)
    {
        key = possible.pop();
    }
    if (key && (key == '115' || key == '83' ) && (e.ctrlKey || e.metaKey) && !(e.altKey))
    {
        e.preventDefault();
         $('#myform #modify').click();
        return false;
    }
    return true;
}); 

//update subcat list in category switch case
$('#category').change(function(){ //detect category switch
    //get value
    var CategorySelected = $(this).val();
    //replace subcat field with new associated values
    $.ajax({
        url:"ajax/ticket_subcat_db.php",
        type:"post",
        data: {CategoryId: CategorySelected},
        async:true,
        success: function(result) {
            var data = JSON.parse(result);
            //reset and populate subcat field
            $("#subcat").empty();
            jQuery.each(data, function(index, value){
                $("#subcat").append("<option value='"+value['id']+"'>"+value['name']+"</option>");
            });
        },
        error: function() {
            console.log('ERROR : unable to get subcat for category '+CategorySelected)
        }
    });
    //remove warning label if value is selected
    if(CategorySelected!=0) {$('#warning_empty_category').css('display', 'none');} else {$('#warning_empty_category').css('display', 'inline');}
});	

//datetimepicker icon default
$.fn.datetimepicker.Constructor.Default = $.extend({}, $.fn.datetimepicker.Constructor.Default, {
    icons: {
        time: 'fa fa-clock text-info',
        date: 'fa fa-calendar text-info',
        up: 'fa fa-arrow-up',
        down: 'fa fa-arrow-down',
        previous: 'fa fa-chevron-left',
        next: 'fa fa-chevron-right',
        today: 'fa fa-calendar-check-o',
        clear: 'fa fa-trash',
        close: 'fa fa-times'
    } });

//datetimepicker format date
var date = moment($('#date_create').val(), 'DD-MM-YYYY hh:mm:ss').toDate();
$('#date_create').datetimepicker({ date:date, format: 'DD/MM/YYYY HH:mm:ss' });
var date = moment($('#date_res').val(), 'DD-MM-YYYY hh:mm:ss').toDate();
$('#date_res').datetimepicker({ date:date, format: 'DD/MM/YYYY HH:mm:ss'});
var date = moment($('#date_hope').val(), 'DD-MM-YYYY').toDate();
$('#date_hope').datetimepicker({ date:date, format: 'DD/MM/YYYY' });
var date = moment($('#start_availability').val(), 'DD-MM-YYYY hh:mm:ss').toDate();
$('#start_availability').datetimepicker({ date:date, format: 'DD/MM/YYYY HH:mm:ss' });
var date = moment($('#end_availability').val(), 'DD-MM-YYYY hh:mm:ss').toDate();
$('#end_availability').datetimepicker({ date:date, format: 'DD/MM/YYYY HH:mm:ss' });
$('#add_calendar_start').datetimepicker({format: 'DD/MM/YYYY HH:mm:ss'});
$('#add_calendar_end').datetimepicker({format: 'DD/MM/YYYY HH:mm:ss'});
$('#add_reminder').datetimepicker({format: 'DD/MM/YYYY HH:mm:ss'});
var date = moment($('#user_validation_date').val(), 'DD-MM-YYYY').toDate();
$('#user_validation_date').datetimepicker({ date:date, format: 'DD/MM/YYYY' });

//remove warning before technician field is value is detected
$('#technician').change(function(){
    if($(this).val()!=0) {$('#technician_warning').css('display', 'none');}
    if($(this).val()==0) {$('#technician_warning').css('display', '');}
})