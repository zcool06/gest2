Files in this folder along with `index.js` file from Ace's root folder, are used for running the demo and generating HTML files.

**You don't need these files**