# GestSup Security

If you find security problem, thanks to report directly by mail at contact AT gestsup DOT fr

# GestSup Bug

Please report other bug type directly on https://gestsup.fr/forum/viewforum.php?f=1

Thanks for your help! 
